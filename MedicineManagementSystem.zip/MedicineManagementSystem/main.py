import tkinter as tk
from tkinter import ttk, messagebox
import pandas as pd
import os

# Constants
DATABASE_FILE = "database.csv"

# Save database
def save_data(data):
    data.to_csv(DATABASE_FILE, index=False)

# Load database
def load_data():
    if os.path.exists(DATABASE_FILE):
        try:
            return pd.read_csv(DATABASE_FILE)
        except pd.errors.EmptyDataError:
            # Create an empty DataFrame if the file is empty
            df = pd.DataFrame(columns=["Medicine Name", "Quantity", "Price"])
            save_data(df)
            return df
    else:
        # If the file doesn't exist, create one with headers
        df = pd.DataFrame(columns=["Medicine Name", "Quantity", "Price"])
        save_data(df)
        return df

# Main Application
class MedicineManagementApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Medicine Management System")
        self.root.geometry("800x500")
        
        # Title Label
        tk.Label(self.root, text="Medicine Management System", font=("Arial", 20, "bold")).pack(pady=10)
        
        # Frames
        self.data_frame = tk.LabelFrame(self.root, text="Medicine Data", padx=10, pady=10, font=("Arial", 12))
        self.data_frame.pack(fill="both", expand=True, padx=10, pady=10)
        
        self.controls_frame = tk.LabelFrame(self.root, text="Controls", padx=10, pady=10, font=("Arial", 12))
        self.controls_frame.pack(fill="x", padx=10, pady=10)
        
        self.build_data_view()
        self.build_controls()
    
    def build_data_view(self):
        # Treeview for data display
        self.tree = ttk.Treeview(self.data_frame, columns=("name", "quantity", "price"), show="headings", height=10)
        self.tree.pack(fill="both", expand=True, side=tk.LEFT)
        
        self.tree.heading("name", text="Medicine Name")
        self.tree.heading("quantity", text="Quantity")
        self.tree.heading("price", text="Price")
        
        self.tree.column("name", width=200)
        self.tree.column("quantity", width=100)
        self.tree.column("price", width=100)
        
        self.scrollbar = ttk.Scrollbar(self.data_frame, orient=tk.VERTICAL, command=self.tree.yview)
        self.tree.configure(yscroll=self.scrollbar.set)
        self.scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        
        self.refresh_data()
    
    def build_controls(self):
        # Input fields
        tk.Label(self.controls_frame, text="Medicine Name:").grid(row=0, column=0, padx=5, pady=5)
        self.name_var = tk.StringVar()
        tk.Entry(self.controls_frame, textvariable=self.name_var, width=20).grid(row=0, column=1, padx=5, pady=5)
        
        tk.Label(self.controls_frame, text="Quantity:").grid(row=0, column=2, padx=5, pady=5)
        self.quantity_var = tk.IntVar()
        tk.Entry(self.controls_frame, textvariable=self.quantity_var, width=10).grid(row=0, column=3, padx=5, pady=5)
        
        tk.Label(self.controls_frame, text="Price:").grid(row=0, column=4, padx=5, pady=5)
        self.price_var = tk.DoubleVar()
        tk.Entry(self.controls_frame, textvariable=self.price_var, width=10).grid(row=0, column=5, padx=5, pady=5)
        
        # Buttons
        tk.Button(self.controls_frame, text="Add", command=self.add_medicine).grid(row=0, column=6, padx=5, pady=5)
        tk.Button(self.controls_frame, text="Update", command=self.update_medicine).grid(row=0, column=7, padx=5, pady=5)
        tk.Button(self.controls_frame, text="Delete", command=self.delete_medicine).grid(row=0, column=8, padx=5, pady=5)
        tk.Button(self.controls_frame, text="Refresh", command=self.refresh_data).grid(row=0, column=9, padx=5, pady=5)
    
    def refresh_data(self):
        # Clear existing data
        for row in self.tree.get_children():
            self.tree.delete(row)
        
        # Load and display data
        data = load_data()
        for _, row in data.iterrows():
            self.tree.insert("", tk.END, values=(row["Medicine Name"], row["Quantity"], row["Price"]))
    
    def add_medicine(self):
        name = self.name_var.get()
        quantity = self.quantity_var.get()
        price = self.price_var.get()
        
        if not name or quantity <= 0 or price <= 0:
            messagebox.showerror("Invalid Input", "Please enter valid details.")
            return
        
        # Update the DataFrame with new data
        data = load_data()
        new_entry = pd.DataFrame([{"Medicine Name": name, "Quantity": quantity, "Price": price}])
        data = pd.concat([data, new_entry], ignore_index=True)
        save_data(data)
        
        self.refresh_data()
        messagebox.showinfo("Success", "Medicine added successfully.")
    
    def update_medicine(self):
        selected_item = self.tree.selection()
        if not selected_item:
            messagebox.showerror("Error", "Please select a medicine to update.")
            return
        
        name = self.name_var.get()
        quantity = self.quantity_var.get()
        price = self.price_var.get()
        
        if not name or quantity <= 0 or price <= 0:
            messagebox.showerror("Invalid Input", "Please enter valid details.")
            return
        
        # Get the index of the selected row
        selected_index = self.tree.index(selected_item[0])
        data = load_data()
        data.loc[selected_index] = {"Medicine Name": name, "Quantity": quantity, "Price": price}
        save_data(data)
        
        self.refresh_data()
        messagebox.showinfo("Success", "Medicine updated successfully.")
    
    def delete_medicine(self):
        selected_item = self.tree.selection()
        if not selected_item:
            messagebox.showerror("Error", "Please select a medicine to delete.")
            return
        
        # Remove the selected row from the DataFrame
        selected_index = self.tree.index(selected_item[0])
        data = load_data()
        data = data.drop(data.index[selected_index])
        save_data(data)
        
        self.refresh_data()
        messagebox.showinfo("Success", "Medicine deleted successfully.")

# Run Application
if __name__ == "__main__":
    root = tk.Tk()
    app = MedicineManagementApp(root)
    root.mainloop()

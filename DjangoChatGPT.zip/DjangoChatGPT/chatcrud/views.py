# chatcrud/views.py
import openai
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from .models import Query
from .serializers import QuerySerializer
from django.conf import settings
from django.http import HttpResponse

def home(request):
    return HttpResponse("Welcome to the ChatGPT Django REST API!")

openai.api_key = settings.OPENAI_API_KEY

class QueryView(APIView):
    def get(self, request):
        queries = Query.objects.all()
        serializer = QuerySerializer(queries, many=True)
        return Response(serializer.data)

    def post(self, request):
        serializer = QuerySerializer(data=request.data)
        if serializer.is_valid():
            user_query = serializer.validated_data['user_query']

            # Call OpenAI API
            try:
                response = openai.ChatCompletion.create(
                    model="gpt-3.5-turbo",
                    messages=[
                        {"role": "user", "content": user_query}
                    ]
                )
                chat_response = response['choices'][0]['message']['content']

                # Save to the database
                query = serializer.save(response=chat_response)
                return Response(QuerySerializer(query).data, status=status.HTTP_201_CREATED)
            except openai.error.OpenAIError as e:
                return Response({"error": str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
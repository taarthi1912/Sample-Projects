# chatcrud/models.py
from django.db import models

class Query(models.Model):
    user_query = models.TextField()
    response = models.TextField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.user_query[:50]
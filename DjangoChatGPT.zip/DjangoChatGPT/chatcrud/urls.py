# chatcrud/urls.py
from django.urls import path
from .views import QueryView

urlpatterns = [
    path('queries/', QueryView.as_view(), name='queries'),
]
from django.shortcuts import render, get_object_or_404, redirect
from .models import Product, Cart
from django.conf import settings
import stripe
from django.conf import settings

stripe.api_key = 'your_stripe_secret_key'


# Product listing
def product_list(request):
    products = Product.objects.all()
    return render(request, 'products/product_list.html', {'products': products})

# Add to cart
def add_to_cart(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    cart_item, created = Cart.objects.get_or_create(product=product)
    if not created:
        cart_item.quantity += 1
    cart_item.save()
    return redirect('cart')

# View cart
def view_cart(request):
    cart_items = Cart.objects.all()
    return render(request, 'products/cart.html', {'cart_items': cart_items})

# Checkout
# def checkout(request):
   #  cart_items = Cart.objects.all()
    # total = sum(item.product.price * item.quantity for item in cart_items)
    # return render(request, 'products/checkout.html', {'total': total, 'cart_items': cart_items})

def checkout(request):
    cart_items = Cart.objects.all()
    total = sum(item.product.price * item.quantity for item in cart_items)

    if request.method == 'POST':
        stripe.PaymentIntent.create(
            amount=int(total * 100),  # Stripe expects amounts in cents
            currency='usd',
            payment_method_types=['card'],
        )
        cart_items.delete()
        return render(request, 'products/success.html')

    return render(request, 'products/checkout.html', {'total': total, 'cart_items': cart_items})



from django.contrib import admin
from .models import Product, Cart

admin.site.register(Product)
admin.site.register(Cart)

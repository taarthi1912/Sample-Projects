import sqlite3

# Database initialization
DB_NAME = "restaurant.db"

def create_tables():
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS orders (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            customer_name TEXT NOT NULL,
            details TEXT NOT NULL,
            total_amount REAL NOT NULL
        )
    """)
    conn.commit()
    conn.close()

def insert_order(customer_name, details, total_amount):
    conn = sqlite3.connect(DB_NAME)
    cursor = conn.cursor()
    cursor.execute("""
        INSERT INTO orders (customer_name, details, total_amount)
        VALUES (?, ?, ?)
    """, (customer_name, details, total_amount))
    conn.commit()
    conn.close()
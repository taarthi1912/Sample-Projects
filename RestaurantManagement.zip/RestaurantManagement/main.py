import tkinter as tk
from tkinter import ttk, messagebox
import sqlite3

# Database setup
from database import create_tables, insert_order

# Create main application window
class RestaurantManagementApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Restaurant Management System")
        self.root.geometry("800x500")
        
        # Title Label
        tk.Label(self.root, text="Restaurant Management System", font=("Arial", 20, "bold")).pack(pady=10)
        
        # Menu Frame
        self.menu_frame = tk.LabelFrame(self.root, text="Menu", font=("Arial", 14), padx=10, pady=10)
        self.menu_frame.pack(side=tk.LEFT, padx=20, pady=20)
        
        # Billing Frame
        self.bill_frame = tk.LabelFrame(self.root, text="Billing", font=("Arial", 14), padx=10, pady=10)
        self.bill_frame.pack(side=tk.RIGHT, padx=20, pady=20)
        
        self.build_menu()
        self.build_billing()
    
    def build_menu(self):
        self.menu = {
            "Pizza": 10,
            "Burger": 8,
            "Pasta": 12,
            "Fries": 5,
            "Salad": 7
        }
        
        self.menu_items = {}
        
        # Display menu items
        for idx, (item, price) in enumerate(self.menu.items()):
            tk.Label(self.menu_frame, text=f"{item} - ${price}", font=("Arial", 12)).grid(row=idx, column=0, pady=5)
            qty_var = tk.IntVar(value=0)
            self.menu_items[item] = qty_var
            tk.Spinbox(self.menu_frame, from_=0, to=10, textvariable=qty_var, width=5).grid(row=idx, column=1, pady=5)
    
    def build_billing(self):
        tk.Label(self.bill_frame, text="Customer Name:", font=("Arial", 12)).grid(row=0, column=0, pady=5)
        self.customer_name = tk.Entry(self.bill_frame, width=30)
        self.customer_name.grid(row=0, column=1, pady=5)
        
        tk.Button(self.bill_frame, text="Generate Bill", command=self.generate_bill).grid(row=1, column=0, columnspan=2, pady=10)
        
        self.bill_text = tk.Text(self.bill_frame, height=15, width=50, state=tk.DISABLED)
        self.bill_text.grid(row=2, column=0, columnspan=2)
    
    def generate_bill(self):
        name = self.customer_name.get()
        if not name:
            messagebox.showerror("Error", "Customer name is required")
            return
        
        total = 0
        bill_details = f"Customer: {name}\n\nItems Ordered:\n"
        for item, qty_var in self.menu_items.items():
            qty = qty_var.get()
            if qty > 0:
                price = self.menu[item] * qty
                total += price
                bill_details += f"{item} x{qty} - ${price}\n"
        
        bill_details += f"\nTotal: ${total}"
        
        # Insert into database
        insert_order(name, bill_details, total)
        
        # Display bill
        self.bill_text.config(state=tk.NORMAL)
        self.bill_text.delete(1.0, tk.END)
        self.bill_text.insert(tk.END, bill_details)
        self.bill_text.config(state=tk.DISABLED)
        messagebox.showinfo("Bill Generated", "Bill has been generated and saved in the database!")

# Initialize app
if __name__ == "__main__":
    create_tables()
    root = tk.Tk()
    app = RestaurantManagementApp(root)
    root.mainloop()
<?php

namespace Config;

use App\Helpers\RouteConstant;

// Create a new instance of our RouteCollection class.
$routes = Services::routes();

/*
 * --------------------------------------------------------------------
 * Router Setup
 * --------------------------------------------------------------------
*/
$routes->setDefaultNamespace('App\Controllers');
$routes->setDefaultController('Home');
$routes->setDefaultMethod('index');
$routes->setTranslateURIDashes(false);
$routes->set404Override();
// The Auto Routing (Legacy) is very dangerous. It is easy to create vulnerable apps
// where controller filters or CSRF protection are bypassed.
// If you don't want to define all routes, please use the Auto Routing (Improved).
// Set `$autoRoutesImproved` to true in `app/Config/Feature.php` and set the following to true.
// $routes->setAutoRoute(false);
/*
 * --------------------------------------------------------------------
 * Route Definitions
 * --------------------------------------------------------------------
 */
// We get a performance increase by specifying the default
// route since we don't have to scan directories.
    $routes->group('admin', ['namespace' => '\App\Controllers\Admin'], static function ($routes) {
    $routes->get('home', 'Home::index', ['as' => 'adminhome']);
    $routes->get('questions/(:num)', 'Questions::questions/$1');
    $routes->post('questions/(:num)', 'Questions::postQuestions/$1');
    $routes->get('questions/edit/(:num)/(:num)', 'Questions::questions/$1/$2/edit');
    $routes->get('questions/(:num)/options', 'QuestionOptions::index/$1');
    $routes->post('questions/delete/(:num)/(:num)', 'Questions::deleteQuestion/$1/$2');

    $routes->get('questions/groups', 'QuestionsGroups::index');
    $routes->post('questions/groups', 'QuestionsGroups::save');
    $routes->post('questions/groups/delete/(:num)', 'QuestionsGroups::delete/$1');
    $routes->get('questions/groups/save/(:num)', 'QuestionsGroups::save/$1');
    $routes->get('questions/groups/edit/(:num)', 'QuestionsGroups::edit/$1');
    
    $routes->get('questions/view/(:num)', 'QuestionsGroups::view/$1');
    $routes->get('user/answer', 'UserAnswer::useranswer');
    $routes->post('useranswer/filter', 'UserAnswer::filter');
    $routes->get('user', 'User::user');
});

$routes->get('/', 'Home::index');
$routes->get(RouteConstant::Home, 'Home::index');
$routes->get('/contact', 'Home::contact');
$routes->get('/about', 'Home::about');
$routes->get(RouteConstant::Register, 'Users::register');
$routes->post(RouteConstant::Register, 'Users::registerSave');
$routes->get(RouteConstant::Login, 'Users::login');
$routes->post(RouteConstant::Login, 'Users::login');
$routes->get(RouteConstant::Logout, 'Users::logout');

$routes->get('/questions', 'Questions::index');
// $routes->get('/instruction/start', 'Instruction::start');
$routes->get('/exam/start', 'ExamStart::exam');
$routes->post('/exam/start', 'ExamStart::exam');
$routes->post('/home', 'Home::index');
$routes->get('/admin/display/results', 'Questions::displayResults');
$routes->post('/questions', 'Questions::submitAnswer');
$routes->post('/questions/saveFocusLossCount', 'Questions::saveFocusLossCount');

$routes->get(RouteConstant::Question, 'Questions::index');
$routes->post(RouteConstant::Question, 'Questions::submitAnswer');

/*
 * --------------------------------------------------------------------
 * Additional Routing
 * --------------------------------------------------------------------
 *
 * There will often be times that you need additional routing and you
 * need it to be able to override any defaults in this file. Environment
 * based routes is one such time. require() additional route files here
 * to make that happen.
 *
 * You will have access to the $routes object within that file without
 * needing to reload it.
 */
if (is_file(APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php')) {
    require APPPATH . 'Config/' . ENVIRONMENT . '/Routes.php';
}

<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\QuestionGroupModel;
use App\Models\QuestionOptionsModel;
use App\Models\QuestionModel;

class QuestionsGroups extends BaseController
{
    public function index()
    {
        $questionGroupModel = new QuestionGroupModel();
        $data['question_groups'] = $questionGroupModel->findAll();

        return view('admin/questiongroups/questiongroup', $data);
    }

    public function save()
    {
        $questionGroupModel = new QuestionGroupModel();
        $data = $this->request->getPost();

        if (isset($data['id']) && !empty($data['id'])) {

            $id = $data['id'];
            $questionGroupModel->update($id, $data);
        } else {

            unset($data['id']);
            $questionGroupModel->insert($data);
        }

        return redirect()->to('/admin/questions/groups');
    }

    public function edit($id)
    {
        $questionGroupModel = new QuestionGroupModel();
        $postData = $this->request->getPost();
        $existingGroup = $questionGroupModel->find($id);

        if (!$existingGroup) {

            return redirect()->to('/admin/questions/groups')->with('error', 'Group not found');
        }

        if (!empty($postData)) {

            $questionGroupModel->update($id, $postData);

            return redirect()->to('/admin/questions/groups')->with('success', 'Group updated successfully');
        }

        return view('admin/questiongroups/questiongroup', [
            "group" => $existingGroup,
            "question_groups" => $questionGroupModel->findAll()
        ]);
    }


    public function delete($id)
    {
        $questionGroupModel = new QuestionGroupModel();

        $delete = $questionGroupModel->delete($id);

        if ($delete) {

            return $this->response->setJSON(['status' => 'success', 'message' => 'Question deleted successfully']);
        } else {

            return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to delete the question']);
        }
    }
    public function view($groupId)
    {
        $questionModel = new QuestionModel();
        $questionOptionsModel = new QuestionOptionsModel();
        $questionGroupModel = new QuestionGroupModel();
        $data['question_groups'] = $questionGroupModel->findAll();
    
        // Retrieve the questions associated with the specified group ID
        $data['questions'] = $questionModel->where('group_id', $groupId)->findAll();

        // Retrieve the options for each question and store them in the $data array
        foreach ($data['questions'] as &$question) {
            $options = $questionOptionsModel->where('question_id', $question['id'])->findAll();
            $question['options'] = $options;
        }

        // Load the view to display the questions and options
        return view('admin/question/viewquestions', $data);
    }
}

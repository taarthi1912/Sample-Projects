<?php

namespace App\Controllers\Admin;
use App\Controllers\BaseController;
use App\Models\UserModel;

class User extends BaseController
{

    public function user()
    {
        $userModel = new UserModel();
        return view('admin/user/user', [
            "title" => "User Details",
            'users' => $userModel->getUsersWithGroupInfo()
        ]);
        // return view('admin/user/user', ["title" => "User Details", 'users' => $userModel->findAll() ]);
    }
    
}

<?php

namespace App\Controllers\Admin;
use App\Controllers\BaseController;
use App\Models\UserModel;
use App\Models\QuestionGroupModel;
use App\Models\UserAnswerModel;
use App\Models\QuestionModel;
use App\Models\QuestionOptionsModel;

class UserAnswer extends BaseController
{
    public function useranswer()
    { 
        $userAnswerModel = new UserAnswerModel();
        $data['user_answer'] = $userAnswerModel->getUserAnswersWithDetails();

        // Get all available question groups and users to populate the filter form
        $questionGroupModel = new QuestionGroupModel();
        $userModel = new UserModel();
        $data['question_groups'] = $questionGroupModel->findAll();
        $data['users'] = $userModel->findAll();
    
        // Load the view and pass the data to it
        return view('admin/useranswer/useranswer', $data, ["title" => "User Answers"]);
    }
    public function filter()
    {
        // Get the selected question group and user from the form submission
        $selectedGroup = $this->request->getPost('questionGroup');
        $selectedUser = $this->request->getPost('selectedUser');
    
        $userAnswerModel = new UserAnswerModel();
        $questionGroupModel = new QuestionGroupModel();
        $userModel = new UserModel();
    
        // Fetch all user answers if no filters are selected
        if (empty($selectedGroup) && empty($selectedUser)) {
            $data['user_answer'] = $userAnswerModel->getUserAnswersWithDetails();
        } else {
            // Filter user answers based on the selected group and user
            $data['user_answer'] = $userAnswerModel->getUserAnswersWithDetailsFiltered($selectedGroup, $selectedUser);
        }
    
        // Get all available question groups and users to populate the filter form
        $data['question_groups'] = $questionGroupModel->findAll();
        $data['users'] = $userModel->findAll();
    
        // Load the view and pass the data to it
        return view('admin/useranswer/useranswer', $data, ["title" => "User Answers"]);
    }
   
}

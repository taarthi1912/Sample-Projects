<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\QuestionModel;
use App\Models\QuestionGroupModel;
use App\Models\QuestionOptionsModel;

class QuestionOptions extends BaseController
{

    public function index($qid)
    {
        $questionOptionModel = new QuestionOptionsModel();
        $options = $questionOptionModel->where('question_id',$qid)->findAll();
        return view('admin/questionoption/questionoptions', [
            "title" => "Question Options",
            "question_id" => $qid,
            "question_options" => $options
        ]);
    }
}

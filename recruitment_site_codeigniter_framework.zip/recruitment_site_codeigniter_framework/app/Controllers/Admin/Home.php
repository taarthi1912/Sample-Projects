<?php

namespace App\Controllers\Admin;
use App\Controllers\BaseController;
use App\Models\QuestionModel;
class Home extends BaseController
{
    public function index()
    {
        return view('admin/home/index', ["title" => "Question Page"]);  
    }
    
}

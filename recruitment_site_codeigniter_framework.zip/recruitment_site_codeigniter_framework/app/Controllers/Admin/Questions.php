<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\QuestionModel;
use App\Models\QuestionOptionsModel;
use App\Models\UserModel;

class Questions extends BaseController
{
    public function questions($id, $qid = null, $view = "")
    {
        // echo $view;
        // exit;
        $questionModel = new QuestionModel();
        $question =  null;
        $options =  null;
        if ($qid) {
            $question  = $questionModel->find($qid);
            $questionOptionModel = new QuestionOptionsModel();
            $options = $questionOptionModel->where('question_id', $qid)->findAll();
        }
        $heading = "ADD";
        if ($view == "view") {
            $heading = "VIEW";
        } else if ($view == "edit") {
            $heading = "EDIT";
        }
        return view('admin/question/questions', [
            "question_id" => $qid,
            "group_id" => $id,
            "questions" => $questionModel->where("group_id", $id)->findAll(),
            "question" => $question,
            "options" => $options,
            "heading" => $heading,
            "title" => "Admin Question Page"
        ]);
    }

    public function options($qid){
        echo $qid;
        exit;
    }

    public function postQuestions($gId)
    {
        $questionModel = new QuestionModel();
        $questionOptionModel = new QuestionOptionsModel();
        $postData =  $this->request->getPost();
        if (isset($postData["question_id"])) {
            // $question  = $questionModel->find($postData["question_id"]);
            $questionModel->update($postData["question_id"], [
                "question" => $postData["question"]
            ]);

            $i = 0;
            $optionChecked = isset($postData['option_checked']) && is_array($postData['option_checked']) ? $postData['option_checked'] : [];
            foreach ($postData["option_ids"] as $option_id) {
                $questionOptionModel->update($option_id, [
                    "option_text" => $postData["option"][$i],
                    'is_correct_answer' => in_array($i, $optionChecked)
                ]);
                //     "is_correct_answer" =>  in_array($i, $postData['option_checked'])
                // ]);

                $i++;
            }
            //edit;
        } else {
            echo json_encode($postData);

            $questionType = isset($postData['option_checked']) && count($postData['option_checked']) == 1 ? 1 : 2;
            $questionId = $questionModel->insert([
                'question' => $postData["question"],
                'group_id' => $gId,
                'content_type' => 1,
                'created_at' => date('Y-m-d H:i:s'),
                'question_type' => $questionType
            ], true);
            //     'question_type' => count($postData['option_checked']) ==1 ? 1 : 2
            // ], true);

            $optionList = [];
            $i = 0;
            $optionChecked = isset($postData['option_checked']) && is_array($postData['option_checked']) ? $postData['option_checked'] : [];
            foreach ($postData["option"] as $option) {
                $optionList[] = [
                    'question_id' => $questionId,
                    'option_text' => $option,
                    'content_type' => 1,
                    'created_at' => date('Y-m-d H:i:s'),
                    'is_correct_answer' => in_array($i, $optionChecked)
                ];
                //     'is_correct_answer' => in_array($i, $postData['option_checked'])
                // ];
                $i++;
            }

            $questionOptionModel->insertBatch($optionList);
        }

        return  redirect()->to("/admin/questions/$gId");
    }
    public function deleteQuestion($groupId, $questionId)
    {
        $questionModel = new QuestionModel();
        $questionOptionModel = new QuestionOptionsModel();

        // Delete the question and its options
        $deletedQuestion = $questionModel->delete($questionId);
        $deletedOptions = $questionOptionModel->where('question_id', $questionId)->delete();

        if ($deletedQuestion && $deletedOptions) {
            // If deletion is successful, return a success response
            return $this->response->setJSON(['status' => 'success', 'message' => 'Question deleted successfully']);
        } else {
            // If deletion fails, return an error response
            return $this->response->setJSON(['status' => 'error', 'message' => 'Failed to delete the question']);
        }
    }
}

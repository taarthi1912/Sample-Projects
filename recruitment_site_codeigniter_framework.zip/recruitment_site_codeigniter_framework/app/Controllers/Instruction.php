<?php

namespace App\Controllers;

use App\Helpers\Utils;


class Instruction extends BaseController
{
    public function start()
    {
        helper('form');
        return view('/user/home');
    }
    
    public function process_start()
    {
        $agree = $this->request->getPost('agree');
        if ($agree) {
            // Redirect to the actual exam page
            return redirect()->to('/questions/index');
        } else {
            // Show an error or validation message
            return redirect()->back()->with('error', 'Please agree to the instructions.');
        }
    }
}
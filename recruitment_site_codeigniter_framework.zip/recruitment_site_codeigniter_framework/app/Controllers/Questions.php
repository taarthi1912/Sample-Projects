<?php

namespace App\Controllers;

use App\Helpers\RouteConstant;
use App\Helpers\Utils;
use App\Models\QuestionModel;
use App\Models\QuestionOptionsModel;
use App\Models\UserAnswerModel;
use App\Models\UserModel;
use App\Models\ResultModel;
use App\Models\QuestionGroupModel;
class Questions extends BaseController
{
    public function index()
    {
        $user = Utils::getCurrentUser();
        $userId = $user['id'];
        $groupId = $user["group_id"];
        if (!$groupId) {
            return redirect()->to(RouteConstant::Home);
        }
        // result where userid, goupid
        $resultModel = new ResultModel();
        $result = $resultModel->where("user_id", $userId)
            ->where("group_id", $groupId)
            ->first();
        $questionModel = new QuestionModel();
        $builder = $questionModel->db->query("select questions.* from questions 
            where questions.id not in (select distinct question_id from user_answer where user_id=$userId) and
            questions.group_id = $groupId
        "); //ORDER BY RAND()
        $allRemainingQuestions = $builder->getResultArray();
        $remainingQuestionCount = count($allRemainingQuestions);
        if ($remainingQuestionCount > 0) {
            $questions = $allRemainingQuestions[0];
            $optionsModel = new QuestionOptionsModel();
            $options = $optionsModel->where("question_id", $questions["id"])->findAll();
            $total =  $questionModel->builder()->where("group_id", $groupId)->countAllResults();

            if (!$result) {
                $questionGroupModel = new QuestionGroupModel();
                $group = $questionGroupModel->find($groupId);
                $userModel = new UserModel();
                $user = $userModel->find($userId); // Get the user's information
                $resultModel->insert([
                    "user_id" => $userId,
                    "user_name" => $user["first_name"] . ' ' . $user["last_name"], // Store user's name
                    "group_id" => $groupId,
                    "group_name" => $group["group_name"],
                    "sub_group_name" => $group["sub_group_name"],
                    "started_at" => date('Y-m-d H:i:s'),
                    "current_question_id" => $questions["id"],
                    "total_questions" => $total
                ]);
            }
            // Load the view to display questions
            return view('questions/index', [
                "title" => "Questions",
                "question" => $questions,
                'total' => $total,
                'current' => ($total - $remainingQuestionCount) + 1,
                'options' => $options
                // "result" => $group
            ]);
        } else {
            if (!isset($result["completed_at"])) {
                $userModel = new UserModel();
                $user = $userModel->find($userId);
                $recipientEmail = $user['email'];
                $this->sendExamCompletionEmail($recipientEmail);
                $totalCorrectAnswer = $this->getCurrectAnswer($userId, $groupId);
                $total =  $questionModel->builder()->where("group_id", $groupId)->countAllResults();
                // $totalQuestionsAnswered = $result['total_answered']; // Retrieve this value based on your logic
                $resultModel->update($result["id"], [
                    "completed_at" => date('Y-m-d H:i:s'),
                    "total_answered" => $result["total_questions"],
                    "total_correct_answer" => $this->getCurrectAnswer($userId, $groupId),
                    "score" => $totalCorrectAnswer * 10, // Calculate score
                    "score_percentage" => ($totalCorrectAnswer / $total) * 100 // Calculate score percentage
                ]);
            }

            return view('questions/index', ["title" => "Questions", "question" => [], 'options' => [],  'total' => 0]);
        }
    }

    private function getCurrectAnswer($userId, $groupId)
    {

        $uanswerModel = new UserAnswerModel();
        $query = "SELECT user_ans.question_id, ( SELECT COUNT(*) FROM question_options 
            WHERE question_id = user_ans.question_id AND is_correct_answer = TRUE ) total_correct_answer, ( 
            SELECT COUNT(*) FROM user_answer ua JOIN question_options qo ON qo.id = ua.option_id 
            WHERE user_id = $userId AND group_id = $groupId AND qo.is_correct_answer = TRUE AND ua.question_id = user_ans.question_id ) 
            total_user_correct_answer FROM `user_answer` user_ans 
            WHERE user_id = $userId AND group_id = $groupId GROUP BY user_ans.question_id";

        $results = $uanswerModel->db->query($query)->getResultArray();

        $sum = 0;
        foreach ($results as $res) {
            if ($res['total_correct_answer'] == $res["total_user_correct_answer"]) {
                $sum++;
            }
        }

        return $sum;
    }
    public function submitAnswer()
    {
        $userId = Utils::getCurrentUserId();
        $data = $this->request->getPost();
        $userAnswerModel = new UserAnswerModel();
        $answers = [];

        foreach ($data["options"] as $option) {
            $ext = $userAnswerModel
                ->where("user_id", $userId)
                ->where("question_id", $data['question_id'])->first();
            if (!$ext) {
                $answers[] = [
                    'group_id' => $data['group_id'],
                    'user_id' => $userId,
                    'question_id' => $data['question_id'],
                    'option_id' => $option,
                    'created_at' => date('Y-m-d H:i:s'),
                ];
            }
        }
        $userAnswerModel->insertBatch($answers, true);
        return redirect()->to('/questions/index');
    }

    public function displayResults()
    {
        $resultModel = new ResultModel();
        $results = $resultModel->findAll(); 

        // Calculate score and score percentage for each result
        foreach ($results as &$result) {
            $result['score'] = $resultModel->getScore($result['total_correct_answer']);
            $result['score_percentage'] = $resultModel->getScorePercentage(
                $result['total_correct_answer'],
                $result['total_questions']
            );
        }
        // Sort the results by score in descending order
        // usort($results, function ($a, $b) {
        //     return $b['score'] - $a['score'];
        // });


        return view('admin/userresult/userresult', ['results' => $results]);
    }
    public function saveFocusLossCount()
    {
        $user = Utils::getCurrentUser();
        $userId = $user['id'];
        $groupId = $user["group_id"];
        if ($groupId && $userId) {
            $resultModel = new ResultModel();
            $result = $resultModel->where("user_id", $userId)
                ->where("group_id", $groupId)
                ->first();
            if (!$result["completed_at"]) {
                $count = ((int) $result["focus_out_count"]);
                $count = $count + 1;
                // echo json_encode("count".$count); exit;
                $resultModel->update($result["id"], [
                    "focus_out_count" => $count
                ]);
                return $this->response->setJSON(["success" => true]);
            }
        }
        return $this->response->setJSON(["success" => false]);
        
    }
    public function examCompleted()
    {
        $userModel = new UserModel();
        $userId = Utils::getCurrentUserId();
        $user = $userModel->find($userId);
        $recipientEmail = $user['email'];
        $this->sendExamCompletionEmail($recipientEmail); 
        return view('questions/index');
    }

    function sendExamCompletionEmail($recipientEmail)
    {
        $subject = 'Exam Completion Confirmation';
        $message = 'Congratulations! You have successfully completed the exam.';
        $email = \Config\Services::email();
        $email->setFrom('taarthi1912@gmail.com', 'TEST');
         $email->setTo('taarthi1912@gmail.com');
        $email->setSubject($subject);
        $email->setMessage($message);

        if ($email->send()) {
            echo 'Email sent successfully.';
        } else {
            echo $email->printDebugger(['headers']);
        }
    }
}

<?php

namespace App\Controllers;

use App\Helpers\Utils;
use App\Models\QuestionModel;
use App\Models\QuestionOptionsModel;
use App\Models\UserAnswerModel;
use App\Models\UserModel;


class ExamStart extends BaseController
{
    public function exam()
    {
        $userId = Utils::getCurrentUserId();
        if (!$this->userHasStartedExam($userId)) {
            return view('/questions/startexam', ["title" => "Start Exam"]);
        }
        
        return redirect()->to('/questions/startexam');
    }

    
    private function userHasStartedExam($userId)
    {
        
    }
}
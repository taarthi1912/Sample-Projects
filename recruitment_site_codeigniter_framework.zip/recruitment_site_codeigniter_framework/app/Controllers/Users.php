<?php

namespace App\Controllers;

use App\Helpers\RouteConstant;
use App\Helpers\Utils;
use App\Models\UserModel;
use App\Models\QuestionGroupModel;
use App\Models\QuestionModel;
use App\Models\UserRoleModel;

class Users extends BaseController
{
    public function register()
    {
        $questionGroupModel = new QuestionGroupModel();
        $group = $questionGroupModel->findAll();

        return view(RouteConstant::Register, ["title" => "register", "success" => '', "groups" => $group]);      
    }

    public function logout()
    {
        Utils::setCurrentUser(null);
        return redirect()->to(RouteConstant::Login);
    }

    public function registerSave()
    {

        $postData = $this->request->getPost();
        $userModel = new UserModel();
        $user = $userModel->where('email', $postData['email'])
            ->orWhere('mobile', $postData['mobile'])
            ->first();
        if ($user) {
            return redirect()->back()->with('error', 'User already Exists ,Email or Mobile No Already Exists');
        }

        $data = [
            'first_name' => $postData['first_name'],
            'last_name' => $this->request->getPost('last_name'),
            'dob' => $this->request->getPost('dob'),
            'mobile' => $this->request->getPost('mobile'),
            'email' => $this->request->getPost('email'),
            'password' => md5($postData['password']),
            'group_id' => $this->request->getPost('applying_for'), // Add the applying_for value to the data array
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
        ];
        // Insert data into the 'users' table
        $userId = $userModel->insert($data);
        if ($userId ) {
            $userRoleModel = new UserRoleModel();
            //user_id = $userId //
            //role_id - 2 // user
            $userRoleModel->insert([
                'role_id' => 2,
                'user_id' => $userId
            ]);

            // Send registration confirmation email
            $this->sendRegistrationEmail($postData['email']);

            // Registration Successful
            return redirect()->to(RouteConstant::Register)->with('success', 'Registration Successful!');
        } else {
            // Registration Failed
            return redirect()->back()->with('error', 'Registration failed. Please try again later.');
        }
    }

    public function login()
    {
        $validationRules = [
            'email' => 'required|valid_email',
            'password' => 'required|min_length[8]',
        ];
        if ($this->request->getMethod() === 'post') {
            $postData = $this->request->getPost();

            $validation = \Config\Services::validation();
            $validation->setRules($validationRules);

            if ($validation->run($postData)) {
                // Validation passed, check login credentials
                $userModel = new UserModel();
                $user = $userModel->where('email', $postData['email'])->first();

                if ($user && md5($postData['password']) == $user['password']) {
                    // Login success
                    
                    $user["is_admin"] = $userModel->isAdmin($user["id"]);
                    Utils::setCurrentUser($user);
                    // Set success message
                    $this->session->setFlashdata('success', 'Login Successful!');
                    return redirect()->to('/home');
                }
            }
            return redirect()->back()->with('error', 'Invalid email or password.');
        } else {
            // Show the login form
            return view(RouteConstant::Login, ["title" => "Login"]);
        }
    }
    public function sendRegistrationEmail()
    {
        // Load the email library
        $email = \Config\Services::email();
        // Set up the email parameters
        $email->setFrom('taarthi1912@gmail.com', 'TEST');
        $email->setTo('taarthi1912@gmail.com');
        $email->setSubject('Registration successful');
        $email->setMessage('Your registratiion is successful with SMTP.');
        // Send the email
        if ($email->send()) {
            echo 'Email sent successfully.';
        } else {
            echo $email->printDebugger(['headers']);
        }
    }
    
    
}

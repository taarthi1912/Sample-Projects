<?php

namespace App\Helpers; 

class RoleConstant {
    const Admin = 1;
    const User = 2;
}

?>
<?php

namespace App\Helpers; 

class RouteConstant {
    const Home = "home";
    const Login = "user/login";
    const Admin = "admin/home";
    const Register = "user/register";
    const Logout = "user/logout";
    const Question = 'questions/index';
    const Questions = 'questions/questions';

}

?>
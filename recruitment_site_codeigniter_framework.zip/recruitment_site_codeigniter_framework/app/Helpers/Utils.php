<?php

namespace App\Helpers; 

class Utils {
    
    static function getCurrentUser(){
        $session = \Config\Services::session();
        return $session->get('user');
    }
    static function getCurrentUserId(){
        $user = Utils::getCurrentUser();
        if($user){
            return $user['id'];
        }
        return null;
    }
    static function setCurrentUser($user){
        $session = \Config\Services::session();
        $session->set('user',$user);
    }
}

?>
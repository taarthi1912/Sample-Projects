<?php

namespace App\Models;

use CodeIgniter\Model;

class UserAnswerModel extends Model
{
    protected $table = 'user_answer';
    protected $primaryKey = 'id';
    protected $useTimestamps = true;

    protected $allowedFields = [
        "group_id",
        "user_id",
        "question_id",
        "option_id",
        "total_questions",
        "user_name",
        "correct_answer",
        "score",
        "created_at"
    ];

   
    public function getUserAnswersWithDetails()
{

    return $this->select('user_answer.id, user_answer.group_id, user_answer.user_id, user_answer.question_id, user_answer.option_id, users.first_name, COUNT(questions.id) as total_questions, SUM(question_options.is_correct_answer) as correct_answer, SUM(question_options.is_correct_answer = user_answer.option_id) as score, user_answer.created_at')
        ->join('users', 'users.id = user_answer.user_id')
        ->join('questions', 'questions.id = user_answer.question_id')
        ->join('question_options', 'question_options.question_id = user_answer.question_id')
        ->groupBy('user_answer.id')
        ->findAll();
}
    public function getUserAnswersWithDetailsFiltered($questionGroup = null, $user = null)
    {
        $builder = $this->select('user_answer.*, users.first_name, COUNT(questions.id) as total_questions, SUM(question_options.is_correct_answer) as correct_answer, SUM(question_options.is_correct_answer = user_answer.option_id) as score')
            ->join('users', 'users.id = user_answer.user_id')
            ->join('questions', 'questions.id = user_answer.question_id')
            ->join('question_options', 'question_options.question_id = user_answer.question_id')
            ->groupBy('user_answer.id');

        // Filter by question group if selected
        if (!empty($questionGroup)) {
            $builder->where('user_answer.group_id', $questionGroup);
        }

        // Filter by user if selected
        if (!empty($user)) {
            $builder->where('user_answer.user_id', $user);
        }

        return $builder->findAll();
    }
}
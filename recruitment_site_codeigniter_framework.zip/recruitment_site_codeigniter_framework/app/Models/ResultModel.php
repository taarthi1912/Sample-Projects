<?php

namespace App\Models;

use CodeIgniter\Model;

class ResultModel extends Model
{
    protected $table = 'result';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'user_id',
        'user_name',
        'group_id',
        'group_name',
        'sub_group_name',
        'started_at',
        'completed_at',
        'focus_out_count',
        'current_question_id',
        'total_questions',
        'total_answered',
        'total_correct_answer',
        'score',
        'score_percentage'
      
    ];
    // protected $useTimestamps = true;
    public function getScore($totalCorrectAnswers)
    {
        return $totalCorrectAnswers * 10;
    }

    public function getScorePercentage($totalCorrectAnswers, $totalQuestions)
    {
        if ($totalQuestions === 0) {
            return 0;
        }

        return ($totalCorrectAnswers / $totalQuestions) * 100;
    }
}
<?php

namespace App\Models;

use CodeIgniter\Model;

class QuestionOptionsModel extends Model
{
   
    protected $table = 'question_options';
    protected $allowedFields = ['option_text', 'question_id',  'content_type', 'is_correct_answer'];
    protected $useTimestamps = true;
}

<?php

namespace App\Models;
//use App\Models\UserModel;

use App\Helpers\RoleConstant;
use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table = 'users';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'first_name',
        'last_name',
        'dob',
        'mobile',
        'email',
        'group_id',
        'password',
        'created_at',
        'updated_at',
    ];

    public function getSubGroupName($userId)
    {
        $user = $this->find($userId);
        if ($user) {
            return $user['sub_group_name'];
        }
        return null;
    }
    public function getUsersWithGroupInfo()
    {
        $builder = $this->db->table('users');
        $builder->select('users.*,roles.role, question_groups.group_name, question_groups.sub_group_name, question_groups.id as group_id');
        $builder->join('user_roles', 'user_roles.user_id = users.id',"left");
        $builder->join('roles', 'roles.id = user_roles.role_id','left');
        $builder->join('question_groups', 'question_groups.id = users.group_id');
        $query = $builder->get();

        return $query->getResultArray();
    }
    
    public function isAdmin($userId) {
        $roleModel = new UserRoleModel();
        $isAdmin = ($roleModel
            ->where("user_id", $userId)
            ->where("role_id", RoleConstant::Admin)
            ->countAllResults()) > 0;

        return $isAdmin;        
    }
}
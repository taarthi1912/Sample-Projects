<?php
namespace App\Models;

use CodeIgniter\Model;

class QuestionGroupModel extends Model
{
    protected $table = 'question_groups';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'group_name',
        'sub_group_name',
        'duration',
        'created_at',
        'updated_at',
        'deleted_at'
    ];
    protected $useTimestamps = true;
}


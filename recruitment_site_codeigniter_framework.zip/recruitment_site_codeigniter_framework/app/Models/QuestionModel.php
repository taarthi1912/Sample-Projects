<?php

namespace App\Models;

use CodeIgniter\Model;

class QuestionModel extends Model
{
    protected $table = 'questions';
    protected $primaryKey = 'id';
    protected $allowedFields = ['group_id', 'question', 'question_type', 'content_type', 'correct_answer', 'created_at', 'updated_at', 'deleted_at'];
    protected $useTimestamps = true;
}
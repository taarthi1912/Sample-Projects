<?php

namespace App\Models;

use App\Helpers\RoleConstant;
use CodeIgniter\Model;

class UserRoleModel extends Model
{
    protected $table = 'user_roles';
    protected $primaryKey = 'id';
    protected $allowedFields = [
        'role_id',
        'user_id',
        
    ];
   
    
    
}
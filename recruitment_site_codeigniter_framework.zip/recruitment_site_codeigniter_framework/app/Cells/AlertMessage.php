<?php

if (session()->getFlashdata('success')): ?>
    <div class="alert alert-success">
        <strong>Success!</strong> <?= session()->getFlashdata('success') ?>
        <?= $successExtraContent ?>
    </div>
<?php endif ?>

<?php if (session()->getFlashdata('error')): ?>
    <div class="alert alert-danger">
        <strong>Error!</strong> <?= session()->getFlashdata('error') ?>
    </div>
<?php endif ?>
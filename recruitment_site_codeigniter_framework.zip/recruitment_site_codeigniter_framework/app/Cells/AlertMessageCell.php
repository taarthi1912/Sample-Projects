<?php

namespace App\Cells;

use CodeIgniter\View\Cells\Cell;

class AlertMessageCell extends Cell
{
    public $successExtraContent;
    
    public function render(): string
    {
        return $this->view('AlertMessage', ['extra' => 'data']);
    }
}

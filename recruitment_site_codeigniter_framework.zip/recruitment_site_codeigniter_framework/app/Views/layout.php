<!DOCTYPE html>
<html lang="en" style="height: 100%;">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="/theme1/assets/img/favicon.png" rel="icon">
  <link href="/theme1/assets/img/apple-touch-icon.png" rel="apple-touch-icon">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Jost:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="/theme1/assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="/theme1/assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="/theme1/assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="/theme1/assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="/theme1/assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="/theme1/assets/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="/theme1/assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
<!-- Include DataTables Bootstrap CSS -->
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.13.6/css/dataTables.bootstrap5.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css">
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.3.0/css/bootstrap.min.css">

  <!-- Template Main CSS File -->
  <link href="/theme1/assets/css/style.css" rel="stylesheet">
  <link href="/theme1/assets/css/custom.css" rel="stylesheet">
  <link href="/theme1/assets/css/custom.css?v1" rel="stylesheet">

<!-- Login and registration  -->
<link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
 <!-- Custom fonts for this template-->
 <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
 <!-- Custom styles for this template-->
 <link href="css/sb-admin.css" rel="stylesheet">

</head>
<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top ">
    <div class="container d-flex align-items-center">

      <h1 class="logo me-auto"><a href="/home">Top</a></h1>
     

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="/home">Home</a></li>
          
          <?php

            use App\Helpers\RouteConstant;
            use App\Helpers\Utils;
            $user = Utils::getCurrentUser();
            if ($user) { ?>
              <?php if($user["is_admin"]): ?>
                <li>
                  <a class="nav-link" href="<?=site_url(RouteConstant::Admin)?>">Admin</a>
                </li>
              <?php endif ?>
              <li class="nav-li-name">Welcome &nbsp; <span><?= $user["first_name"] ?></span>
                <a class="getstarted" href="<?=site_url(RouteConstant::Logout)?>">Logout</a>
              </li>
            <?php } else { ?>
              <li><a class="getstarted scrollto" href="<?= site_url(RouteConstant::Register) ?>">Register</a></li>
            <?php } ?>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>

      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->
  <?= $this->renderSection('content') ?>

  <!-- ======= Footer ======= -->
  <footer id="footer">


    
    <div class="container footer-bottom clearfix">
      <div class="copyright">
        &copy; Copyright 2023 <strong><span>Testing</span></strong>All rights reserved.
      </div>

    </div>
  </footer><!-- End Footer -->

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="/theme1/assets/vendor/aos/aos.js"></script>
  <script src="/theme1/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="/theme1/assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="/theme1/assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="/theme1/assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="/theme1/assets/vendor/waypoints/noframework.waypoints.js"></script>
  <script src="/theme1/assets/vendor/php-email-form/validate.js"></script>
  <!-- Include Include jQuery DataTables and Bootstrap JS -->
  <script src="https://code.jquery.com/jquery-3.7.0.js"></script>
  <script src="https://cdn.datatables.net/1.13.6/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.13.6/js/dataTables.bootstrap5.min.js"></script>

  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

  <!-- Template Main JS File -->
  <script src="/theme1/assets/js/main.js"></script>
  
  <script>
    $(document).ready(function() {
        $('#example').DataTable({
            order: [[3, 'desc']], // Default ordering on the 4th column (index 3) in descending order
            paging: true,         // Enable pagination
            searching: true,      // Enable search bar
            info: true            // Show information about the table
        });
    });
</script>
<?= $this->renderSection('script') ?>
</body>

</html>
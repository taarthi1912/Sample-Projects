<?= $this->extend('layout') ?>
<?= $this->section('content') ?>

<main id="main">
    <section id="about" class="about">
        <div class="container" data-aos="fade-up">
            <div class="section-title">
                <h3>EXAM INSTRUCTIONS</h3>
            </div>
            <div class="container table-responsive py-5">
                <h3>Please read the following instructions carefully:</h3>
                <br>
                <ol>
                    <li>
                        <h4>Login Instructions:</h4>
                    </li>
                    <ul>
                        <li>Log in using your assigned credentials.</li>
                        <li>Ensure that you are using a secure and stable internet connection.</li>
                        <li>Use a modern web browser to access the exam platform.</li>
                        <li>Do not share your login credentials with anyone.</li>
                    </ul>
                    <li>
                        <h4>Exam Format:</h4>
                    </li>
                    <ul>
                        <li>The exam consists of multiple-choice questions.</li>
                        <li>You have a specific time limit to complete the exam.</li>
                        <li>Each question has a specified point value.</li>
                        <li>Unanswered questions will not be counted against you.</li>
                        <li>You can navigate between questions using the provided navigation buttons.</li>
                    </ul>
                    <li>
                        <h4>Technical Requirements:</h4>
                    </li>
                    <ul>
                        <li>Close all unnecessary applications and browser tabs to optimize performance.</li>
                        <li>Ensure your device's camera and microphone are functional, if required.</li>
                        <li>Disable pop-up blockers for the exam platform domain.</li>
                    </ul>
                    <li>
                        <h4>Exam Conduct:</h4>
                    </li>
                    <ul>
                        <li>Do not use any unauthorized resources, including books, notes, or online searches.</li>
                        <li>Do not communicate with anyone during the exam.</li>
                        <li>Copying or sharing questions is strictly prohibited and may result in disqualification.</li>
                        <li>If you experience technical issues, immediately contact the exam support team.</li>
                    </ul>
                    <li>
                        <h4>Submission:</h4>
                    </li>
                    <ul>
                        <li>Submit your answers before the exam timer runs out.</li>
                        <li>Review your answers before submitting as you cannot make changes afterward.</li>
                    </ul>
                </ol>
                <br>
                <form id="exam-form" action="/questions/index" method="post">
                    <div class="form-check">
                        <input type="checkbox" class="form-check-input" id="check1" name="agree" value="1">
                        <label class="form-check-label" for="check1"><b>I agree to the exam instructions</b></label>
                    </div>
                    <br>
                    <div class="mt-3">
                        <button type="button" class="btn btn-secondary" id="start-button">Click here to start</button>
                    </div>
                </form>
            </div>
        </div>
        <script>
            document.getElementById('start-button').addEventListener('click', function() {
                if (document.getElementById('check1').checked) {
                    window.location.href = '/questions/index'; // Redirect to exam page
                } else {
                    alert('Please check the checkbox to agree to the exam instructions.');
                }
            });
        </script>

    </section><!-- End About Us Section -->
</main>

<?= $this->endSection() ?>
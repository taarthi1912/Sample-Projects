<?= $this->extend('layout') ?>
<?= $this->section('content') ?>
 
<!-- <main id="main"> -->
<main id="main">
<div class="container py-5">
        <?php if ($question) : ?>
            <div class="row justify-content-center">
            <div class="col-md-8">
            <h1>Questions
                <span>
                    <?php if ($total) : ?>
                        <span style="font-size: small;">(<?= $current ?> out of <?= $total ?>)</span>
						
                    <?php endif ?>
                </span>
            </h1>
            <div class="row">
                <!-- Loop through the questions data and display them -->

                <script type="text/javascript">
                    window.onblur = function() {
                        $.ajax({
                            type: 'POST',
                            url: '/questions/saveFocusLossCount',
                            success: function(response) {
                                console.log('response.', response);
                            },
                            error: function(e) {
                                console.log("Error", e);
                            }
                        });
                    };
                </script>
                
                    <div class="col-md-6">
                        <div class="card mb-4">
                            <div class="card-body">
                                <h5 class="card-title"><?= $question['question'] ?></h5>
                                <form method="post">
                                <input type="hidden" name="group_id" value="<?= $question['group_id'] ?>">
                                <input type="hidden" name="question_id" value="<?= $question['id'] ?>">
                                <?php if (!empty($options)) : ?>
                                    <?php foreach ($options as $option) : ?>
                                        <label class="list-group-item">
                                            <?php if ($question["question_type"] == "2") : ?>
                                                <input name="options[]" class="form-check-input me-1" type="checkbox" value="<?= $option["id"] ?>">
                                            <?php elseif ($question["question_type"] == "1") : ?>
                                                <input name="options[]" class="form-check-input me-1" type="radio" value="<?= $option["id"] ?>">
                                            <?php endif ?>
                                            <?= $option["option_text"] ?>
                                        </label>
                                    <?php endforeach ?>
                                <?php endif ?>
                                <div class="mt-3">
                                    <!-- <button onclick="submitQuiz()">Submit Quiz</button> -->
                                    <button type="submit" class="btn btn-primary">Submit</button>
                                </div>
                                            </form>
                            </div>
                        </div>
                    </div>
                
                </div>
            <?php else : ?>
                <div class="mt-3">
                    <h2><b>EXAM COMPLETED</b></h2>
                    <br>
                    <h3>
                        <p>Congratulations! You have successfully completed the exam.</p>
                    </h3>
                </div>
            <?php endif ?>

    </div>
</main><!-- End #main -->


<?= $this->endSection() ?>
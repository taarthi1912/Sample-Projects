<?= $this->extend('layout') ?>
<?= $this->section('content') ?>

<main id="main">
    <div class="container table-responsive py-5">
    <!-- <div class="container mt-5"> -->
            <h1>Welcome to the Exam!</h1>

            <form method="post" action="/questions">
                <div class="mt-3 mb-5">
                    <button type="submit" class="btn btn-primary"><a href="/questions/index">Start Exam</button>
                </div>
            </form>
        
    </div>
</main><!-- End #main -->

<?= $this->endSection() ?>
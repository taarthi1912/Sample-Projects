<?= $this->extend('layout') ?>
<?= $this->section('content') ?>

<main id="main">
    <div class="container table-responsive py-5">
        <div class="container">

            <h1>Exam Instructions</h1>
            <p>Please read the following instructions carefully:</p>
<ol>
    <li>Login Instructions:</li>
    <ul>
        <li>Log in using your assigned credentials.</li>
        <li>Ensure that you are using a secure and stable internet connection.</li>
        <li>Use a modern web browser to access the exam platform.</li>
        <li>Do not share your login credentials with anyone.</li>
    </ul>

    <li>Exam Format:</li>
    <ul>
        <li>The exam consists of multiple-choice questions.</li>
        <li>You have a specific time limit to complete the exam.</li>
        <li>Each question has a specified point value.</li>
        <li>Unanswered questions will not be counted against you.</li>
        <li>You can navigate between questions using the provided navigation buttons.</li>
    </ul>

    <li>Technical Requirements:</li>
    <ul>
        <li>Close all unnecessary applications and browser tabs to optimize performance.</li>
        <li>Ensure your device's camera and microphone are functional, if required.</li>
        <li>Disable pop-up blockers for the exam platform domain.</li>
    </ul>

    <li>Exam Conduct:</li>
    <ul>
        <li>Do not use any unauthorized resources, including books, notes, or online searches.</li>
        <li>Do not communicate with anyone during the exam.</li>
        <li>Copying or sharing questions is strictly prohibited and may result in disqualification.</li>
        <li>If you experience technical issues, immediately contact the exam support team.</li>
    </ul>

    <li>Submission:</li>
    <ul>
        <li>Submit your answers before the exam timer runs out.</li>
        <li>Review your answers before submitting as you cannot make changes afterward.</li>
    </ul>
</ol>

            <?= form_open('/exam/start') ?>
            <label>
                <input type="checkbox" name="agree" value="1"> I agree to the exam instructions
            </label>
            <br>
            <div class="mt-3">
            <button type="submit" class="btn btn-dark">Click here to start</button>
            </div>
            <!-- <button type="submit">Click here to start</button> -->
            <?= form_close() ?>

            <?php if (isset($validation)) : ?>
                <?= $validation->listErrors() ?>
            <?php endif; ?>

        </div>
    </div>
</main><!-- End #main -->

<?= $this->endSection() ?>
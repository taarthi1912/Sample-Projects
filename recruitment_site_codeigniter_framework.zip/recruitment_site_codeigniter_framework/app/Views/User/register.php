<?php

use App\Helpers\RouteConstant;

$this->extend('layout');
$this->section('content');
?>
<main id="main">
    <div class="container">
        <!-- Display success message -->
        <?= view_cell('AlertMessageCell',  [
            'successExtraContent' => "<a href='" . site_url(RouteConstant::Login) . "'>Click here to login</a>"
        ]) ?>

        <div class="container mt-5">
            <div class="card card-login mx-auto mt-5 w-50" style="border: 7px solid black;">
                <div class="card-header" style="background-color: lightgray">
                    <h3>Register an Account</h3>
                </div>
                <div class="card">
                    <div class="card-body">


                        <form method="post" action="<?= site_url(RouteConstant::Register) ?>">

                            <div class="mb-3">
                                <label for="first_name" class="form-label">First Name:</label>
                                <input type="text" name="first_name" class="form-control <?= isset($validation) && $validation->hasError('first_name') ? 'is-invalid' : '' ?>" required>
                                <div class="invalid-feedback"><?= isset($validation) ? $validation->getError('first_name') : '' ?></div>

                            </div>
                            <div class="mb-3">
                                <label for="last_name" class="form-label">Last Name:</label>
                                <input type="text" name="last_name" class="form-control <?= isset($validation) && $validation->hasError('last_name') ? 'is-invalid' : '' ?>" required>
                                <div class="invalid-feedback"><?= isset($validation) ? $validation->getError('last_name') : '' ?></div>
                            </div>
                            <div class="mb-3">
                                <label for="dob" class="form-label">Date of Birth:</label>
                                <input type="date" name="dob" class="form-control <?= isset($validation) && $validation->hasError('dob') ? 'is-invalid' : '' ?>" required>
                                <div class="invalid-feedback"><?= isset($validation) ? $validation->getError('dob') : '' ?></div>
                            </div>
                            <div class="mb-3">
                                <label for="mobile" class="form-label">Mobile:</label>
                                <input type="text" name="mobile" class="form-control <?= isset($validation) && $validation->hasError('mobile') ? 'is-invalid' : '' ?>" pattern="[0-9]{10}" title="Please enter a 10-digit phone number" required>
                                <div class="invalid-feedback"><?= isset($validation) ? $validation->getError('mobile') : '' ?></div>
                            </div>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email:</label>
                                <input type="email" name="email" class="form-control <?= isset($validation) && $validation->hasError('email') ? 'is-invalid' : '' ?>" required>
                                <div class="invalid-feedback"><?= isset($validation) ? $validation->getError('email') : '' ?></div>
                            </div>
                            <div class="mb-3">
                                <label for="applying_for" class="form-label">Applying For:</label>
                                <div class="position-relative">
                                    <select name="applying_for" class="form-control <?= isset($validation) && $validation->hasError('applying_for') ? 'is-invalid' : '' ?>" required>
                                        <option value="" selected disabled>Select an option</option>
                                        <?php foreach ($groups as $group) : ?>
                                            <option value="<?= $group['id'] ?>"><?= $group['sub_group_name'] ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <span class="arrow-symbol"></span>
                                </div>
                                <div class="invalid-feedback"><?= isset($validation) ? $validation->getError('applying_for') : '' ?></div>
                            </div>
                            <div class="mb-3">
                                <label for="password" class="form-label">Password:</label>
                                <input type="password" name="password" class="form-control <?= isset($validation) && $validation->md5($postData['password']) ? 'is-invalid' : '' ?>" required>
                                <div class="invalid-feedback"><?= isset($validation) ? $validation->getError('password') : '' ?></div>
                            </div>
                            <div class="text-center mb-3">
                                <button type="submit" class="btn btn-primary btn-block">Register</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
</main><!-- End #main -->
<?= $this->endSection() ?>
<?php

use App\Helpers\RouteConstant;

$this->extend('layout');
$this->section('content');
?>
<main id="main">
    <div class="container">
        <?= view_cell('AlertMessageCell') ?>

        <!-- <div class="container mt-5"> -->
       
            <div class="card card-login mx-auto mt-5 w-50" style="border: 7px solid black;">
            
                <div class="card-header" style="background-color: lightgray">
                    <h3>Login</h3>
                </div>
                <div class="card">
                <div class="card-body">
                    <form method="post" action="<?= site_url(RouteConstant::Login) ?>">
                        <div class="mb-3">
                            <label for="email" class="form-label">Email:</label>
                            <input type="email" name="email" class="form-control <?= isset($validation) && $validation->hasError('email') ? 'is-invalid' : '' ?>" required>
                            <div class="invalid-feedback"><?= isset($validation) ? $validation->getError('email') : '' ?></div>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Password:</label>
                            <input type="password" name="password" class="form-control <?= isset($validation) && $validation->md5($postData['password']) ? 'is-invalid' : '' ?>" required>
                            <div class="invalid-feedback"><?= isset($validation) ? $validation->getError('password') : '' ?></div>

                        </div>
                        <div class="text-center mb-3">
                            <button type="submit" class="btn btn-primary btn-block">Login</button>
                        </div>
                    </form>
                    <div class="text-center">
                        <a class="d-block small mt-3" href="/user/register">Register an Account</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
</main>
<?= $this->endSection() ?>
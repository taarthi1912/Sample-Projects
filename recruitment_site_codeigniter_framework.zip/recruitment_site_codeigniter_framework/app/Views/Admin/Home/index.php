<?php

use App\Helpers\RouteConstant;

$this->extend('admin/layout');
$this->section('content');
?>
<main id="main">
    <div class="container table-responsive py-5">
        <div class="dashboard-content">
            <h1 class="dashboard-title">Welcome to Admin Dashboard</h1>
        </div>
        <div class="container-fluid">
            <div class="row">
                <!-- Sidebar -->
                <nav id="sidebar" class="col-md-3 col-lg-2 d-md-block bg-light sidebar">
                    <div class="position-sticky">
                    <div class="w-100 p-3" style="background-color: #eee;">
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link scrollto active" href="/home">Home</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link scrollto active" href="/questions/index">Exam</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link scrollto active" href="/admin/questions/1">Questions</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link scrollto active" href="/admin/questions/groups">Questions Group</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link scrollto active" href="/admin/user">User</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link scrollto active" href="/admin/user/answer">User Answer</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link scrollto active" href="/admin/display/results">User Result</a>
                            </li>
                           
                        </ul>
                        </div>
                    </div>
                </nav>
                <!-- Main Content -->
                <!-- <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                   
                    <div class="dashboard-content">
                        <h2 class="dashboard-subtitle">Site Settings</h2>
                        <p>Welcome to the admin dashboard! Here you can manage various aspects of the recruitment process.</p>
                    </div>
                </main> -->
            </div>
        </div>
    </div>
</main>
<?= $this->endSection() ?>
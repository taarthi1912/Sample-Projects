<?php

use App\Helpers\RouteConstant;

$this->extend('admin/layout');
$this->section('content');

$heading = isset($group) ? "EDIT" : "ADD";

?>

<main id="main">

    <div class="container table-responsive py-5">
        
        <form id="questionGroupForm" method="post" action="/admin/questions/groups">
            <h2><?= $heading ?> QUESTION GROUP</h2>
            <br>
            <br>
            <input type="hidden" name="id" value="<?= isset($group['id']) ? $group['id'] : '' ?>">
            <div class="form-group">
                <label for="group_name"><b>Group Name</b></label>
                <input type="text" value="<?= isset($group) ? $group["group_name"] : '' ?>" name="group_name" id="group_name" class="form-control" />
            </div>

            <div class="form-group">
                <label for="sub_group_name"><b>Sub Group Name</b></label>
                <input type="text" value="<?= isset($group) ? $group["sub_group_name"] : '' ?>" name="sub_group_name" id="sub_group_name" class="form-control" />
            </div>

            <div class="form-group">
                <label for="duration"><b>Duration</b></label>
                <input type="text" value="<?= isset($group) ? $group["duration"] : '' ?>" name="duration" id="duration" class="form-control" />
            </div>

            <div class="mt-4 mb-5">
                <button type="submit" class="btn btn-primary"> <?= $heading ?> Question Group</button>
            </div>
        </form>

        
        <table id="example" class="table table-striped table-bordered" style="width:100%">
            <thead class="thead-dark">
                <tr>
                    <th scope="col">#</th>
                    <th scope="col">Group Name</th>
                    <th scope="col">Sub Group Name</th>
                    <th scope="col">Duration</th>
                    <th scope="col">Created At</th>
                    <th scope="col">Updated At</th>
                    <th scope="col">Deleted At</th>
                    <th scope="col">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($question_groups as $index => $group) : ?>
                    <tr>
                        <th scope="row"><?= $index + 1 ?></th>
                        <td><?= $group['group_name'] ?></td>
                        <td><?= $group['sub_group_name'] ?></td>
                        <td><?= $group['duration'] ?></td>
                        <td><?= $group['created_at'] ?></td>
                        <td><?= $group['updated_at'] ?></td>
                        <td><?= $group['deleted_at'] ?></td>
                        <td class="actions" >
                            <a href="/admin/questions/groups/edit/<?= $group['id'] ?>">
                                <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="green" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit">
                                    <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                                    <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
                                </svg>
                            </a>
                            <a href="javascript:void(0);" onclick="deleteGroup(<?= $group['id'] ?>)">
                                <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="red" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-trash">
                                    <polyline points="3 6 5 6 21 6"></polyline>
                                    <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                                </svg>  </a>
                                <a href="/admin/questions/view/<?= $group['id'] ?>">
                                
                                <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-eye">
                                    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
                                    <circle cx="12" cy="12" r="3" />
                                </svg> </a>
                                <a href=" /admin/questions/<?= $group['id'] ?>">
                                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-plus-circle">
                                    <circle cx="12" cy="12" r="10" />
                                    <line x1="12" y1="8" x2="12" y2="16" />
                                    <line x1="8" y1="12" x2="16" y2="12" />
                                </svg>
                            </a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

</main>

<script>
    function deleteGroup(id) {
        if (confirm('Are you sure you want to delete this question group?')) {
            $.ajax({
                type: 'POST',
                url: '/admin/questions/groups/delete/' + id,
                success: function(response) {
                    // Check if the deletion was successful
                    if (response.status === 'success') {
                        window.location.reload();
                    } else {
                        alert('Failed to delete the question group.');
                    }
                },
                error: function() {
                    alert('Failed to delete the question group.');
                }
            });
        }
    }
</script>
<?= $this->endSection() ?>
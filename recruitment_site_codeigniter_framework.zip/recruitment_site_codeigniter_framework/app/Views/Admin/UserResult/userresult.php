<?php

use App\Helpers\RouteConstant;

$this->extend('admin/layout');
$this->section('content');
?>
<main id="main">

    <div class="container table-responsive py-5">

        <h2> USERS RESULTS</h2>
        <br>
        <br>
        <table id="example" class="table table-striped table-bordered" style="width:100%">
            <thead class="thead-dark">
                <tr>
                    <th>ID</th>
                    <th>Group ID</th>
                    <th>User ID</th>
                    <th>User Name</th>
                    <th>Group Name</th>
                    <th>Sub Group Name</th>
                    <th>Focus Out Count</th>
                    <th>Current Question Id</th>
                    <th>Total Questions</th>
                    <th>Total Correct Answer</th>  
                    <th>Score</th>
                    <th>Score Percentage</th>
                    <th>Started At</th>
                    <th>Completed At</th>
                </tr>
            </thead>
            
            <tbody id="result-table-body">

                <?php foreach ($results as $row) : ?>
                  
                    <tr class="result-row">
                        <td><?= $row['id'] ?></td>
                        <td><?= $row['group_id'] ?></td>
                        <td><?= $row['user_id'] ?></td>
                        <td><?= $row['user_name'] ?></td>
                        <td><?= $row['group_name'] ?></td>
                        <td><?= $row['sub_group_name'] ?></td>
                        <td><?= $row['focus_out_count'] ?></td>
                        <td><?= $row['current_question_id'] ?></td>
                        <td><?= $row['total_questions'] ?></td>
                        <td><?= $row['total_correct_answer'] ?></td>
                        <td><?= $row['score'] ?></td>
                        <td><?= $row['score_percentage']; ?>%</td>
                        <td><?= $row['started_at'] ?></td>
                        <td><?= $row['completed_at'] ?></td>
                    </tr>

                <?php endforeach; ?>
                

            </tbody>
            </table>
        <!-- </table> -->
    </div>


</main>

<?= $this->endSection() ?>
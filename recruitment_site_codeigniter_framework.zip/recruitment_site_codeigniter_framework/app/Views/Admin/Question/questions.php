<?php

use App\Helpers\RouteConstant;

$this->extend('admin/layout');
$this->section('content');
?>
<main id="main">
    
        <div class="container table-responsive py-5">
            <form id="questionForm" method="post" action="/admin/questions/<?= $group_id ?>">
                <h2><?= $heading ?> QUESTIONS </h2>
                <br>
                <br>
                <div class="form-group">
                    <label for="question"><b>Enter the Questions</b></label>
                    <input type="text" value="<?= $question ? $question["question"] : "" ?>" name="question" id="question" class="form-control" />
                    <?php if ($question) : ?>
                        <input type="hidden" name="question_id" value="<?= $question["id"] ?>" />


                        <?php
                        $i = 0;
                        foreach ($options as $option) { ?>
                            <div class="form-group">
                                <input type="hidden" name="option_ids[]" value="<?= $option["id"] ?>" ?>
                                <label for="option1">Option <?= ($i + 1) ?>: <input type="checkbox" <?= $option["is_correct_answer"] ? "checked" : "" ?> name="option_checked[]" value="<?= $i ?>" /> correct answer </label>
                                <input type="text" value="<?= $option["option_text"] ?>" name="option[]" class="form-control option" />
                            </div>
                        <?php $i++;
                        } ?>
                    <?php else : ?>
                        <div class="form-group">
                            <label for="option1"><b>Option 1:</b> <input type="checkbox" name="option_checked[]" value="0" /> correct answer </label>
                            <input type="text" name="option[]" class="form-control option" />
                        </div>
                        <div class="form-group">
                            <label for="option2"><b>Option 2:</b> <input type="checkbox" name="option_checked[]" value="1" /> correct answer </label>
                            <input type="text" name="option[]" class="form-control option" />
                        </div>
                        <div class="form-group">
                            <label for="option3"><b>Option 3: </b><input type="checkbox" name="option_checked[]" value="2" /> correct answer </label>
                            <input type="text" name="option[]" class="form-control option" />
                        </div>
                        <div class="form-group">
                            <label for="option4"><b>Option 4:</b> <input type="checkbox" name="option_checked[]" value="3" /> correct answer </label>
                            <input type="text" name="option[]" class="form-control option" />
                        </div>
                    <?php endif ?>

                </div>
                <div class="mt-3 mb-5">
                    <?php if ($heading !== "View") : ?>
                        <button type="addquestion" class="btn btn-primary"><?= $question ? "Update" : "Add"  ?> Question</button>
                    <?php endif ?>
                </div>
            </form>

            <table id="example" class="table table-striped table-bordered" style="width:100%">
                <thead class="thead-dark">
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Question Id</th>
                        <th scope="col">Questions</th>
                        <th scope="col">Group Id</th>
                        <th scope="col">Options</th>
                        <th scope="col">Created At</th>
                        <th scope="col">Update At</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($questions as $index => $question) : ?>
                        <tr>
                            <th scope="row"><?= $index + 1 ?></th>
                            <td><?= $question['id'] ?></td>
                            <td><?= $question['question'] ?></td>
                            <td><?= $question['group_id'] ?></td>
                            <td>
                                <a href="/admin/questions/<?= $question['id'] ?>/options">
                                    View
                                </a>
                            </td>
                            <td><?= $question['created_at'] ?></td>
                            <td><?= $question['updated_at'] ?></td>
                            <td class="actions">
                                <a href="/admin/questions/edit/<?= $question['group_id'] ?>/<?= $question['id'] ?>">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="green" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-edit">
                                        <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                                        <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
                                    </svg>
                                </a>
                                <a href="javascript:void(0);" onclick="confirmDelete(this,<?= $question['group_id'] ?>, <?= $question['id'] ?>)">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="red" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="feather feather-trash">
                                        <polyline points="3 6 5 6 21 6"></polyline>
                                        <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                                    </svg>
                                </a>

                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    
</main>
<!-- <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script> -->
<script>
    
    function confirmDelete(el, groupId, questionId) {
        // console.log($(el));
        if (confirm('Are you sure you want to delete this question?')) {
            $.ajax({
                type: 'POST',
                url: '/admin/questions/delete/' + groupId + '/' + questionId,
                success: function(response) {
                    // Check if the deletion was successful
                    if (response.status === 'success') {
                        window.location.reload();
                        // Remove the row from the table on successful deletion
                        $('tr[data-question-id="' + questionId + '"]').remove();
                    } else {
                        alert('Failed to delete the question.');
                    }
                },
                error: function() {
                    alert('Failed to delete the question.');
                }
            });
        }
    }
</script>


<?= $this->endSection() ?>
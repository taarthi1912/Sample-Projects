<?php

use App\Helpers\RouteConstant;

$this->extend('admin/layout');
$this->section('content');

$selectedGroupId = $_GET['view'] ?? null; // Get the selected group ID from the query parameter
$heading = '<h2>VIEW QUESTIONS AND OPTIONS</h2>';

// Assume that $question_groups contains an array of available groups

$selectedGroup = null;

foreach ($question_groups as $index => $group) {
    if ($group['group_name'] == $selectedGroupId) {
        $selectedGroup = $group;
        break;
    }
}
?>

<main id="main">


    <div class="container table-responsive py-5">
    

    <?php if ($selectedGroup) : ?>
            <?php $dynamicHeading = $heading . $selectedGroup['sub_group_name'] . ' (Group ID: ' . $selectedGroup['id'] . ')'; ?>
            <h1><?= $dynamicHeading ?></h1>
        <?php else : ?>
            <h1><?= $heading ?></h1>
        <?php endif; ?>

            <br>
            <br>
        <table id="example" class="table table-striped table-bordered" style="width:100%">

            <thead class="thead-dark">
                <tr>
                    <th>#</th>
                    <th>Question</th>
                    <th>Options</th>

                </tr>
            </thead>

            <tbody>
                <?php foreach ($questions as $index => $question) : ?>
                    <tr>
                        <td><?= $index + 1 ?></td>
                        <td><?= $question['question'] ?></td>
                        <td>
                            <ul>
                                <?php foreach ($question['options'] as $option) : ?>
                                    <li><?= $option['option_text'] ?></li>
                                <?php endforeach; ?>
                            </ul>
                        </td>

                    </tr>
                <?php endforeach; ?>

            </tbody>
        </table>


    </div>

</main>
<?= $this->endSection() ?>
<?php

use App\Helpers\RouteConstant;

$this->extend('admin/layout');
$this->section('content');
?>
<main id="main">
    <div class="container">

        <div class="container table-responsive py-5">
            <form action="<?= base_url('admin/useranswer/filter') ?>" method="post">
                <h2> USERS ANSWER</h2>
                <br>
                <br>
                <div class="form-group">
                    <label for="questionGroup"><b>Select Question Group:</b></label>
                    <select name="questionGroup" id="questionGroup" class="form-control">
                        <option value="">All</option>
                        <?php foreach ($question_groups as $group) : ?>
                            <option value="<?= $group['id'] ?>"><?= $group['group_name'] ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <br>
                <div class="form-group">
                    <label for="selectedUser"><b>Select User:</b></label>
                    <br>
                    <select name="selectedUser" id="selectedUser" class="form-control">
                        <option value="">All</option>
                        <?php foreach ($users as $user) : ?>
                            <option value="<?= $user['id'] ?>"><?= $user['first_name'] ?></option>
                        <?php endforeach; ?>
                    </select>
                    <div class="mt-3 mb-5">
                        <button type="submit" class="btn btn-primary">Filter</button>
                    </div>
            </form>

            <table id="example" class="table table-striped table-bordered" style="width:100%">
                <thead class="thead-dark">
                    <tr>
                        <th>ID</th>
                        <th>Group ID</th>
                        <th>User ID</th>
                        <th>Question ID</th>
                        <th>Option ID</th>
                        <th>User Name</th>
                        <th>Created At</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($user_answer as $answer) : ?>
                        <tr>
                            <td><?= $answer['id'] ?></td>
                            <td><?= $answer['group_id'] ?></td>
                            <td><?= $answer['user_id'] ?></td>
                            <td><?= $answer['question_id'] ?></td>
                            <td><?= $answer['option_id'] ?></td>
                            <td><?= $answer['first_name'] ?></td>
                            <td><?= $answer['created_at'] ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <script>
                        $(document).ready(function() {
                            new DataTable('#example', {
                                order: [
                                    [3, 'desc']
                                ],
                                paging: true,
                                searching: true,
                                info: true
                            });
                        });
                    </script>
                </tbody>
            </table>
        </div>
    </div>

</main>
<?= $this->endSection() ?>
<?php

use App\Helpers\RouteConstant;

$this->extend('admin/layout');
$this->section('content');
?>



<main id="main">

    <div class="container">
        <title>Question Options</title>
        
            <a class="btn btn-primary" href="/admin/questions/<?= $question_id ?>">Back</a>
            
            <div class="table-responsive py-5">
            <table id="example" class="table table-striped table-bordered" style="width:100%">
                    <thead class="thead-dark">

                        <tr>
                            <th scope="col">#</th>
                            <th scope="col">Option Text</th>
                            <th scope="col">Content Type</th>
                            <th scope="col">Question Id</th>
                            <th scope="col">Correct Answer</th>
                            <th scope="col">Created At</th>
                            <th scope="col">Updated At</th>
                            <th scope="col">Deleted At</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($question_options as $options) : ?>
                            <tr>
                                <td><?= $options['id'] ?></td>
                                <td><?= $options['option_text'] ?></td>
                                <td><?= $options['content_type'] ?></td>
                                <td><?= $options['question_id'] ?></td>
                                <td><?= $options['is_correct_answer'] ? "True" : "False" ?></td>
                                <td><?= $options['created_at'] ?></td>
                                <td><?= $options['updated_at'] ?></td>
                                <td><?= $options['deleted_at'] ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        
    </div>
</main>

<?= $this->endSection() ?>
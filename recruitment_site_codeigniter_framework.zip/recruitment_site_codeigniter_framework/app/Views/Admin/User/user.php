<?php

use App\Helpers\RouteConstant;

$this->extend('admin/layout');
$this->section('content');
?>
<main id="main">      
        <div class="container table-responsive py-5">
            <h2> USERS INFORMATION</h2>
            <br>
            <br>
            <table id="example" class="table table-striped table-bordered" style="width:100%">
                <thead class="thead-dark">
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">First Name</th>
                        <th scope="col">Last Name</th>
                        <th scope="col">Role</th>
                        <th scope="col">Date of Birth</th>
                        <th scope="col">Mobile</th>
                        <th scope="col">Email</th>
                        <th scope="col">Group Id</th>
                        <th scope="col">Group Name</th>
                        <th scope="col">Applied For</th>
                        <th scope="col">Created At</th>
                        <th scope="col">Updated At</th>
                        <th scope="col">Deleted At</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($users as $user) : ?>
                        <tr>
                            <td><?= $user['id'] ?></td>
                            <td><?= $user['first_name'] ?></td>
                            <td><?= $user['last_name'] ?></td>
                            <td><?= $user['role'] ?></td>
                            <td><?= $user['dob'] ?></td>
                            <td><?= $user['mobile'] ?></td>
                            <td><?= $user['email'] ?></td>
                            <td><?= $user['group_id'] ?></td>
                            <td><?= $user['group_name'] ?></td>
                            <td><?= $user['sub_group_name'] ?></td>
                            <td><?= $user['created_at'] ?></td>
                            <td><?= $user['updated_at'] ?></td>
                            <td><?= $user['deleted_at'] ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div> 
</main>
<?= $this->endSection() ?>
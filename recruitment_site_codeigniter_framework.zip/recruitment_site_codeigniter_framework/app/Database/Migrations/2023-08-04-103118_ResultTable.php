<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class ResultTable extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id' => [
                'type' => 'INT',
                'unsigned' => true,
                'auto_increment' => true,
            ],
            'user_id' => [
                'type' => 'INT',
                'unsigned' => true,
            ],
            'user_name' => [
                'type' => 'VARCHAR',
                'constraint' => 255,
            ],
            'group_id' => [
                'type' => 'INT',
                'unsigned' => true,
            ],
            'group_name' => [
                'type' => 'VARCHAR',
                'constraint' => 255,
            ],
            'sub_group_name' => [
                'type' => 'VARCHAR',
                'constraint' => 255,
            ],
            'started_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'completed_at' => [
                'type' => 'DATETIME',
                'null' => true,
            ],
            'focus_out_count' => [
                'type' => 'INT',
                'default' => 0,
            ],
            'current_question_id' => [
                'type' => 'INT',
                'unsigned' => true,
                'null' => true,
            ],
            'total_questions' => [
                'type' => 'INT',
                'default' => 0,
            ],
            'total_answered' => [
                'type' => 'INT',
                'default' => 0,
            ],
            'total_correct_answer' => [
                'type' => 'INT',
                'default' => 0,
            ],
            'score' => [
                'type' => 'INT',
                'default' => 0,
            ],
            'score_percentage' => [
                'type' => 'INT',
                'default' => 0,
            ],
        ]);

        $this->forge->addPrimaryKey('id');
        $this->forge->addForeignKey('user_id', 'users', 'id');
        $this->forge->addForeignKey('group_id', 'question_groups', 'id');
        $this->forge->createTable('result');
    }

    public function down()
    {
        $this->forge->dropTable('result');
    }
}

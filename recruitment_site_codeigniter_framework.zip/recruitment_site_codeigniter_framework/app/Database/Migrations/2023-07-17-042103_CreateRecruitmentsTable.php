<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateRecruitmentsTable extends Migration
{
    public function up()
    {
         // Create a table question_groups

    $this->forge->addField([
        'id' => [
            'type' => 'INT',
            'unsigned' => true,
            'auto_increment' => true,
        ],
        'group_name' => [
            'type' => 'VARCHAR',
            'constraint' => 255,
        ],
        'sub_group_name' => [
            'type' => 'VARCHAR',
            'constraint' => 255,
        ],
        'duration' => [
            'type' => 'INT',
        ],
        
        'created_at' => [
            'type' => 'DATETIME',
            'null' => true,
        ],
        'updated_at' => [
            'type' => 'DATETIME',
            'null' => true,
        ],
        'deleted_at' => [
            'type' => 'DATETIME',
            'null' => true,
        ],
    ]);

    $this->forge->addPrimaryKey('id');
    $this->forge->createTable('question_groups');
        // Create a table users
        $this->forge->addField([
            'id' => [
                'type'           => 'INT',
                'constraint'     => 5,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'first_name' => [
                'type'       => 'VARCHAR',
                'constraint' => '100',
            ],
            'last_name' => [
                'type' => 'VARCHAR',
                'constraint' => '100',
                
            ],
            'dob' => [
                'type' => 'DATE',
               
                
            ],
            'mobile' => [
                'type' => 'VARCHAR',
                'constraint' => '20',
                
            ],
            'email' => [
                'type' => 'VARCHAR',
                'constraint' => '100', 
            ],

            'group_id' => [
                'type' => 'INT',
                'unsigned' => true,
                'null' => true,
            ],
            'password'=> [
                'type' => 'VARCHAR',
                'constraint' => '200', 
            ],
            
            'created_at' => [
                'type' => 'DATETIME',
                'null' => true,
               
            ],
            'updated_at' => [
                'type' => 'DATETIME',
                'null' => true,
               
            ],
            'deleted_at' => [
                'type' => 'DATETIME',
                
                'null' => true,
            ],
        ]);
        $this->forge->addKey('id', true);
        
        $this->forge->addForeignKey('group_id', 'question_groups', 'id');
        $this->forge->createTable('users');
   
// Create a table roles
        $this->forge->addField([
            'id' => [
                'type' => 'INT',
                'unsigned' => true,
                'auto_increment' => true,
            ],
            'role' => [
                'type' => 'VARCHAR',
                'constraint' => 100,
            ],
        ]);

        $this->forge->addPrimaryKey('id');
        $this->forge->createTable('roles');
   
   

    // Create a table questions
    $this->forge->addField([
        'id' => [
            'type' => 'INT',
            'unsigned' => true,
            'auto_increment' => true,
        ],
        'group_id' => [
            'type' => 'INT',
            'unsigned' => true,
            
        ],
        'question' => [
            'type' => 'TEXT',
        ],
        'question_type' => [
            'type' => 'INT',
            'unsigned' => true,
            
        ],
        'content_type' => [
            'type' => 'INT',
            'unsigned' => true,
            
        ],
        
        'created_at' => [
            'type' => 'DATETIME',
            'null' => true,
        ],
        'updated_at' => [
            'type' => 'DATETIME',
            'null' => true,
        ],
        'deleted_at' => [
            'type' => 'DATETIME',
            'null' => true,
        ],
    ]);

    $this->forge->addPrimaryKey('id');
    $this->forge->createTable('questions');

    // Create a table question_options
    $this->forge->addField([
        'id' => [
            'type' => 'INT',
            'unsigned' => true,
            'auto_increment' => true,
        ],
        'option_text' => [
            'type' => 'TEXT',
        ],
        'content_type' => [
            'type' => 'INT',
            'unsigned' => true,
        ],
        'question_id' => [
            'type' => 'INT',
            'unsigned' => true,
        ],
        'is_correct_answer' => [
            'type' => 'BOOLEAN',
            'default' => false,
        ],
        'created_at' => [
            'type' => 'DATETIME',
            'null' => true,
        ],
        'updated_at' => [
            'type' => 'DATETIME',
            'null' => true,
        ],
        'deleted_at' => [
            'type' => 'DATETIME',
            'null' => true,
        ],
    ]);

    $this->forge->addPrimaryKey('id');
    $this->forge->addForeignKey('question_id', 'questions', 'id');
    $this->forge->createTable('question_options');
// Create a table user_answer
    $this->forge->addField([
        'id' => [
            'type' => 'INT',
            'unsigned' => true,
            'auto_increment' => true,
        ],
        'group_id' => [
            'type' => 'INT',
            'unsigned' => true,
        ],
        'user_id' => [
            'type' => 'INT',
            'unsigned' => true,
        ],
        'question_id' => [
            'type' => 'INT',
            'unsigned' => true,
        ],
        'option_id' => [
            'type' => 'INT',
            'unsigned' => true,
        ],
        'created_at' => [
            'type' => 'DATETIME',
        ],
        'updated_at' => [
            'type' => 'DATETIME',
            'null' => true,
        ],
    ]);

    $this->forge->addPrimaryKey('id');
    $this->forge->addForeignKey('group_id', 'question_groups', 'id');
    $this->forge->addForeignKey('user_id', 'users', 'id');
    $this->forge->addForeignKey('question_id', 'questions', 'id');
    $this->forge->addForeignKey('option_id', 'question_options', 'id');
    $this->forge->createTable('user_answer');
// Create a table user_roles
    $this->forge->addField([
        'id' => [
            'type' => 'INT',
            'unsigned' => true,
            'auto_increment' => true,
        ],
        'role_id' => [
            'type' => 'INT',
            'unsigned' => true,
        ],
        'user_id' => [
            'type' => 'INT',
            'unsigned' => true,
        ],
    ]);

    $this->forge->addPrimaryKey('id');
    $this->forge->addForeignKey('role_id', 'roles', 'id');
    $this->forge->addForeignKey('user_id', 'users', 'id');
    $this->forge->createTable('user_roles');

    $seeder = \Config\Database::seeder();
    $seeder->call('QuestionGroups');
    $seeder->call('Users');
    $seeder->call('Roles');
    $seeder->call('UserRoles');
    $seeder->call('Questions');
    $seeder->call('QuestionOptions');

}
//Create a table login

    public function down()
    {
        
    
        $this->forge->dropTable('user_answer');
        $this->forge->dropTable('user_roles');
        $this->forge->dropTable('question_options');
        $this->forge->dropTable('questions');
        $this->forge->dropTable('users');
        $this->forge->dropTable('roles');
        $this->forge->dropTable('question_groups');
    }

}

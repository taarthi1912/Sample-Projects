<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class QuestionGroups extends Seeder
{
    public function run()
    {
    $data = [
        [
            'group_name' => 'One Year',
            'sub_group_name' => 'PHP',
            'duration' => 60,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
        ],
        [
            'group_name' => 'Two Year',
            'sub_group_name' => 'Magento',
            'duration' => 90,
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
        ],
        [
            'group_name' => 'SAMPLE',
            'sub_group_name' => 'Instructions',
            'duration' => 30,       
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
        ],
        [
            'group_name' => 'Four Year',
            'sub_group_name' => 'HTML',
            'duration' => 90,  
            'created_at' => date('Y-m-d H:i:s'),
            'updated_at' => date('Y-m-d H:i:s'),
        ],
        
    ];

    $this->db->table('question_groups')->insertBatch($data);
}
}

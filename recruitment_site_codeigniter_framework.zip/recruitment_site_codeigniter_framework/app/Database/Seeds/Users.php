<?php

namespace App\Database\Seeds;

use CodeIgniter\Database\Seeder;

class Users extends Seeder
{
    public function run()
    {
        $data = [
            [
                'first_name' => 'Test1',
                'last_name' => 'John',
                'dob' => '1990-01-15',
                'mobile' => '9225675674',
                'email' => 'test1@gmail.com',
                'group_id' => 1,
                'password'=>md5('Test1@123'),
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ],
            [
                'first_name' => 'Test2',
                'last_name' => 'Smith',
                'dob' => '1985-05-20',
                'mobile' => '9876543210',
                'email' => 'test2@gmail.com',
                'group_id' => 2,
                'password'=>md5('Test2@123'),
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ],
            [
                'first_name' => 'Test3',
                'last_name' => 'T',
                'dob' => '1985-06-20',
                'mobile' => '9876543510',
                'email' => 'test3@gmail.com',
                'group_id' => 3,
                'password'=>md5('Test3@123'),
                'created_at' => date('Y-m-d H:i:s'),
                'updated_at' => date('Y-m-d H:i:s'),
            ],
            
        ];

        $this->db->table('users')->insertBatch($data);
    }
}

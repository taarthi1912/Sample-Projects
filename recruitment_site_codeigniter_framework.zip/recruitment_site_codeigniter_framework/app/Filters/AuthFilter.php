<?php

namespace App\Filters;

use CodeIgniter\Filters\FilterInterface;
use CodeIgniter\HTTP\RequestInterface;
use CodeIgniter\HTTP\ResponseInterface;
use App\Helpers\RouteConstant;
use App\Helpers\Utils;

class AuthFilter implements FilterInterface
{
    public function before(RequestInterface $request, $arguments = null)
    {
        $user = Utils::getCurrentUser();
        if(!$user){
            return redirect()->to(RouteConstant::Login);
        } else if($request->getUri()->getSegment(1) == "admin"){
            if(!$user["is_admin"]){
                return redirect()->to(RouteConstant::Login);
            }
        }
    }

    public function after(RequestInterface $request, ResponseInterface $response, $arguments = null)
    {
        // Do something here
    }
}